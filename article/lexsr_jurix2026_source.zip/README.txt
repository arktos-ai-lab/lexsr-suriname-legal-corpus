JURIX 2026, paper #258: LexSR camera-ready LaTeX sources

Files
  lexsr_jurix2026.tex   paper source (bibliography inline, no figures)
  IOS-Book-Article.cls  IOS Press book article class, as distributed with the template

Build (pdfLaTeX, run three times to resolve cross-references):
  pdflatex lexsr_jurix2026.tex
  pdflatex lexsr_jurix2026.tex
  pdflatex lexsr_jurix2026.tex

Packages from a standard TeX distribution: fontenc (T1), mathptmx, lm (Latin Modern
typewriter, lmtt), soul, longtable, array, hyperref (loaded by the class). Built with MiKTeX.
